/*
 * rss_process.h
 *
 * Functions to call an external command and
 * to communicate with it.
 *
 * (C) 2002 by Reinhold Software Services
 * This software package is published as open source.
 * You are allowed to use and distribute it in unmodified
 * or modified form as you want.
 * But notice that there is NO WARRANTY! We do not claim
 * this software package useful for any purpose!
 * USE IT AT YOUR OWN RISK!!!
 *
 * You can contact us via e-mail at: info@rsas.de
 */

#ifndef RSS_PROCESS_H
#define RSS_PROCESS_H

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdio.h>

/* If you use the DLL version of rss_process
 * define RSS_PROCESS_DLL in your program!
 * Never define RSS_PROCESS_IMPL in your code because it
 * is used to implement the dll.
 */
#ifndef RSS_PROCESS_DECL_SPEC
  #ifdef RSS_PROCESS_DLL
    #ifdef RSS_PROCESS_IMPL
      #define RSS_PROCESS_DECL_SPEC extern __declspec(dllexport)
    #else
      #define RSS_PROCESS_DECL_SPEC extern __declspec(dllimport)
    #endif
  #else
    #define RSS_PROCESS_DECL_SPEC
  #endif
#endif

/* For some compilers you need to specify special calling
 * conventions.
 * If the calling conventions for your compiler are not
 * properly handled by default you can specify them with the
 * preprocessor symbol RSS_PROCESS_CALL
 */
#ifndef RSS_PROCESS_CALL
  #if defined(RSS_PROCESS_DLL)
    #if defined(__BORLANDC__) || defined(__BCPLUSPLUS__)
      #define RSS_PROCESS_CALL __stdcall
    #else
      #define RSS_PROCESS_CALL
    #endif
  #else
    #define RSS_PROCESS_CALL
  #endif
#endif


struct RSS_Process_Struct;
typedef struct RSS_Process_Struct *RSS_Process;

enum RSS_Process_Flags_Enum
{
  RSS_PROCESS_NONE = 0,
  RSS_PROCESS_TO   = 1,
  RSS_PROCESS_FROM = 2,
  RSS_PROCESS_ALL  = RSS_PROCESS_TO | RSS_PROCESS_FROM
};
typedef enum RSS_Process_Flags_Enum RSS_Process_Flags;

enum RSS_Process_KillMode_Enum
{
  RSS_PROCESS_WAIT        = 0,
  RSS_PROCESS_IMMEDIATELY = 1
};
typedef enum RSS_Process_KillMode_Enum RSS_Process_KillMode;


/* Create a new process handle and initialize it.
 * This function doesn't create a process on OS level.
 * Use rss_process_start() for that...
 *
 * parameters:
 * - the name of the process (for example its absolute pathname)
 * - the arguments (beginning with argv[1]!) for the process
 *   (null terminated list of const char *)
 * 
 * return code:
 * 0 : an error occured
 * otherwise the handle of the process structure is returned
 */
RSS_PROCESS_DECL_SPEC RSS_Process RSS_PROCESS_CALL rss_process_create(const char *name, ...);

/* The same, but here you specify the arguments using an
 * array. Note: argv[0] must be the name of the process.
 * (For example its absolute pathname.)
 * The array must be null terminated.
 */
RSS_PROCESS_DECL_SPEC RSS_Process RSS_PROCESS_CALL rss_process_createv(const char **argv);


/* Releases the resources used by the process.
 * If the process is still running, killMode specifies if
 * the function shall wait until its termination or if the
 * process shall be killed immediately...
 */
RSS_PROCESS_DECL_SPEC void RSS_PROCESS_CALL rss_process_release(RSS_Process process, RSS_Process_KillMode killMode);

/* Creates an OS level process and executes the command
 * specified by the process structure.
 * Use 'flags' to control if you wish to communicate to
 * the process via its standard i/o file descriptors...
 *
 * return code:
 * 0 : an error occured
 * 1 : everything is ok
 */
RSS_PROCESS_DECL_SPEC int RSS_PROCESS_CALL rss_process_start(RSS_Process process, int flags);

/* Terminates the process.
 * If you don't call this function, the process will be terminated
 * by rss_process_release().
 * After calling rss_process_stop() you can restart the
 * process by calling rss_process_start()...
 */
RSS_PROCESS_DECL_SPEC void RSS_PROCESS_CALL rss_process_stop(RSS_Process process, RSS_Process_KillMode killMode);

/* Returns the stdout file descriptor of the specified process.
 * The process must have been started!
 *
 * return code:
 *  -1 : an error occured or no file descriptor is available
 *  otherwise the filedescriptor gets returned..,.
 */
RSS_PROCESS_DECL_SPEC int RSS_PROCESS_CALL rss_process_getFromFd(RSS_Process process);

/* the same for the stdin file descriptor of the process...
 */
RSS_PROCESS_DECL_SPEC int RSS_PROCESS_CALL rss_process_getToFd(RSS_Process process);

/* These two functions return the appropriate FILE *
 * objects...
 */
RSS_PROCESS_DECL_SPEC FILE *RSS_PROCESS_CALL rss_process_getFromFile(RSS_Process process);
RSS_PROCESS_DECL_SPEC FILE *RSS_PROCESS_CALL rss_process_getToFile(RSS_Process process);


/* Use these functions if you want to close the
 * i/o file objects of the process communication...
 * Never close the file descriptors or FILE * objects
 * directly!
 * If you don't call these close functions the communication
 * object's get closed when the process gets terminated.
 */
RSS_PROCESS_DECL_SPEC void RSS_PROCESS_CALL rss_process_closeFrom(RSS_Process process);
RSS_PROCESS_DECL_SPEC void RSS_PROCESS_CALL rss_process_closeTo(RSS_Process process);


/* Returns true if the specified process is still alive and
 * false if not.
 */
RSS_PROCESS_DECL_SPEC int RSS_PROCESS_CALL rss_process_isAlive(RSS_Process process);

/* On Unix this function returns the process id, on Windows it
 * returns the process handle
 */
RSS_PROCESS_DECL_SPEC unsigned int RSS_PROCESS_CALL rss_process_getId(RSS_Process process);


RSS_PROCESS_DECL_SPEC int RSS_PROCESS_CALL rss_process_send(RSS_Process process, const char *buf, int size);
RSS_PROCESS_DECL_SPEC int RSS_PROCESS_CALL rss_process_receive(RSS_Process process, char *buf, int size);


#ifdef __cplusplus
}
#endif


#endif
