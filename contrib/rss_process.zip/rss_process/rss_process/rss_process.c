/*
 * rss_process.c
 * 
 * (C) 2002 by Reinhold Software & Services
 * This software package is published as open source.
 * You are allowed to use and distribute it in unmodified
 * or modified form as you want.
 * But notice that there is NO WARRANTY! We do not claim
 * this software package useful for any purpose!
 * USE IT AT YOUR OWN RISK!!!
 *
 * You can contact us via e-mail at: info@rsas.de
 */

#include "rss_process.h"


#ifdef WIN32

/* WINDOWS implementation */

#include <windows.h>
#include <process.h>
#include <io.h>
#include <stdio.h>
#include <fcntl.h>


struct RSS_Process_Struct
{
  const char  *name;
  const char **argv;
  int          argc;
  HANDLE       processHandle;
  HANDLE       commPipe[2];
  int          commFd[2];
  FILE        *fromFile;
  FILE        *toFile;
  int          running;
  int          newConsole;
};


static RSS_Process createProcessObject(const char **argv)
{
  const char  *arg;
  int          i;
  RSS_Process  process = (RSS_Process)malloc(sizeof(struct RSS_Process_Struct));

  if(!process)
    return 0;

  if(!argv || !argv[0])
  {
    free(process);
    return 0;
  }

  process->name = strdup(argv[0]);

  /* count the number of arguments */
  process->argc = 0;
  arg = argv[0];
  while(arg)
  {
    process->argc++;
    arg = argv[process->argc];
  }

  process->argv = (const char **)malloc((process->argc + 1) * sizeof(const char *));
  if(!process->argv)
  {
    free(process);
    return 0;
  }

  /* duplicate arguments (incl. null termination!) */
  for(i = 0; i <= process->argc; i++)
    process->argv[i] = strdup(argv[i]);

  /* initialize the other fields... */
  process->processHandle = 0;
  process->fromFile      = 0;
  process->toFile        = 0;
  process->running       = 0;
  process->commPipe[0]   = 0;
  process->commPipe[1]   = 0;
  process->commFd[0]     = 0;
  process->commFd[1]     = 0;
  process->newConsole    = 0;

  return process;
}


RSS_Process RSS_PROCESS_CALL rss_process_create(const char *name, ...)
{
  va_list arglist;
  int i;
  int j;
  const char *arg;
  const char **argv;
  RSS_Process process;

  /* count arguments */
  i = 0;
  va_start(arglist, name);
  arg = va_arg(arglist, const char *);
  while(arg)
  {
    i++;
    arg = va_arg(arglist, const char *);
  }
  va_end(arglist);

  /* create argument vector */
  argv = (const char **)malloc((i + 2) * sizeof(const char *));
  if(!argv)
    return 0;

  i = 0;
  argv[i] = strdup(name);
  i++;
  va_start(arglist, name);
  arg = va_arg(arglist, const char *);
  while(arg)
  {
    argv[i] = strdup(arg);
    i++;
    arg = va_arg(arglist, const char *);
  }
  va_end(arglist);
  argv[i] = 0;

  /* initialize the process structure... */
  process = rss_process_createv(argv);

  /* release argument vector (it has been copied by rss_process_createv()) */
  for(j = 0; j <= i; j++)
    free((void *)argv[i]);
  free((void *)argv);

  return process;
}



RSS_Process rss_process_createv(const char **argv)
{
  return createProcessObject(argv);
}


void rss_process_release(RSS_Process process, RSS_Process_KillMode killMode)
{
  int i;

  if(!process)
    return;

  rss_process_stop(process, killMode);

  free((void *)process->name);
  for(i = 0; i <= process->argc; i++)
    free((void *)process->argv[i]);
  free((void *)process->argv);

  free(process);

  /* from and to channels have been closed by rss_process_stop()... */
}


int rss_process_start(RSS_Process process, int flags)
{
  HANDLE              parentChannels[2];
  HANDLE              childChannels[2];
  HANDLE              stdChannels[2];
  SECURITY_ATTRIBUTES secAttrs;
  char               *commandLine;
  int                 i;
  int                 len;
  PROCESS_INFORMATION processInformation;
  STARTUPINFO         startupInfo;

  parentChannels[0] = 0;
  parentChannels[1] = 0;
  childChannels[0]  = 0;
  childChannels[1]  = 0;

  if(!process || process->running)
    return 0;

  process->newConsole = AllocConsole();

  stdChannels[0] = GetStdHandle(STD_INPUT_HANDLE);
  stdChannels[1] = GetStdHandle(STD_OUTPUT_HANDLE);

  if(flags != RSS_PROCESS_NONE)
  {
    secAttrs.nLength = sizeof(SECURITY_ATTRIBUTES);
    secAttrs.bInheritHandle = TRUE;
    secAttrs.lpSecurityDescriptor = 0;

    if(flags & RSS_PROCESS_TO)
    {
      if(!CreatePipe(&childChannels[0], &parentChannels[1], &secAttrs, 0))
        return 0;

      if(!SetStdHandle(STD_INPUT_HANDLE, childChannels[0]))
        return 0;

      if(!DuplicateHandle(GetCurrentProcess(), parentChannels[1],
            GetCurrentProcess(), &process->commPipe[1], 0, FALSE, DUPLICATE_SAME_ACCESS))
      {
        return 0;
      }

      CloseHandle(parentChannels[1]);
    }

    if(flags & RSS_PROCESS_FROM)
    {
      if(!CreatePipe(&parentChannels[0], &childChannels[1], &secAttrs, 0))
        return 0;

      if(!SetStdHandle(STD_OUTPUT_HANDLE, childChannels[1]))
        return 0;

      if(!DuplicateHandle(GetCurrentProcess(), parentChannels[0],
            GetCurrentProcess(), &process->commPipe[0], 0, FALSE, DUPLICATE_SAME_ACCESS))
      {
        return 0;
      }

      CloseHandle(parentChannels[0]);
    }
  }

  /* create the command line */
  len = 0;
  for(i = 0; i < process->argc; i++)
    len += (int)(strlen(process->argv[i])) + 1;
  len++;

  commandLine = (char *)malloc(len);
  commandLine[0] = 0;
  for(i = 0; i < process->argc; i++)
  {
    strcat(commandLine, process->argv[i]);
    strcat(commandLine, " ");
  }

  /* create the process */
  ZeroMemory(&processInformation, sizeof(PROCESS_INFORMATION));
  ZeroMemory(&startupInfo, sizeof(STARTUPINFO));
  startupInfo.cb = sizeof(STARTUPINFO);

  if(!CreateProcess(0, commandLine, 0, 0, TRUE, 0 /*CREATE_NO_WINDOW*/,
        0, 0, &startupInfo, &processInformation))
  {
    return 0;
  }
  process->processHandle = processInformation.hProcess;

  free(commandLine);

  /* close child handles */
  if(flags & RSS_PROCESS_TO)
    CloseHandle(childChannels[0]);

  if(flags & RSS_PROCESS_FROM)
    CloseHandle(childChannels[1]);

  /* restore stdandard handles */
  SetStdHandle(STD_INPUT_HANDLE,  stdChannels[0]);
  SetStdHandle(STD_OUTPUT_HANDLE, stdChannels[1]);

  /* handle errors */
  if(!process->processHandle)
  {
    if(flags & RSS_PROCESS_TO)
    {
      CloseHandle(process->commPipe[1]);
      process->commPipe[1] = 0;
    }

    if(flags & RSS_PROCESS_FROM)
    {
      CloseHandle(process->commPipe[0]);
      process->commPipe[0];
    }

    return 0;
  }

  if(flags & RSS_PROCESS_TO)
  {
    process->commFd[1] = _open_osfhandle((intptr_t)process->commPipe[1], _O_TEXT);
    if(process->commFd[1] < 0)
      return 0;
  }

  if(flags & RSS_PROCESS_FROM)
  {
    process->commFd[0] = _open_osfhandle((intptr_t)process->commPipe[0], _O_TEXT);
    if(process->commFd[0] < 0)
      return 0;
  }

  process->running  = 1;
  process->fromFile = 0;
  process->toFile   = 0;

  return 1;
}


int rss_process_isAlive(RSS_Process process)
{
  unsigned long exitCode;

  if(!process || !process->running)
    return 0;

  process->running = GetExitCodeProcess(process->processHandle, &exitCode) && exitCode == STILL_ACTIVE;
  return process->running;
}


void rss_process_stop(RSS_Process process, RSS_Process_KillMode killMode)
{
  unsigned long exitCode;

  if(!process || !process->running)
    return;

  if(process->newConsole)
  {
    FreeConsole();
    process->newConsole = 0;
  }

  if(killMode == RSS_PROCESS_IMMEDIATELY)
  {
    exitCode = STILL_ACTIVE;
    if(GetExitCodeProcess(process->processHandle, &exitCode) && exitCode == STILL_ACTIVE)
    {
      TerminateProcess(process->processHandle, 256);
      process->processHandle = 0;
    }
  }

  /* close communication channels */
  rss_process_closeTo(process);
  rss_process_closeFrom(process);

  if(killMode == RSS_PROCESS_WAIT)
    cwait((int *)&exitCode, (intptr_t)process->processHandle, 0);

  process->running = 0;
}


int rss_process_getFromFd(RSS_Process process)
{
  if(!process || !process->running)
    return 0;

  return process->commFd[0];
}


int rss_process_getToFd(RSS_Process process)
{
  if(!process || !process->running)
    return 0;

  return process->commFd[1];
}


FILE *rss_process_getFromFile(RSS_Process process)
{
  if(!process || !process->running)
    return 0;

  if(!process->fromFile)
    process->fromFile = fdopen(process->commFd[0], "r");

  return process->fromFile;
}


FILE *rss_process_getToFile(RSS_Process process)
{
  if(!process || !process->running)
    return 0;

  if(!process->toFile)
    process->toFile = fdopen(process->commFd[1], "w");

  return process->toFile;
}


void rss_process_closeFrom(RSS_Process process)
{
  if(!process)
    return;

  if(process->fromFile)
  {
    fclose(process->fromFile);
    process->fromFile = 0;
  }

  if(process->commFd[0] > 0)
  {
    close(process->commFd[0]);
    process->commFd[0] = 0;
  }

  if(process->commPipe[0])
  {
/*    CloseHandle(process->commPipe[0]);  this handle should already be closed because of the former closing actions... */
    process->commPipe[0] = 0;
  }
}


void rss_process_closeTo(RSS_Process process)
{
  if(!process)
    return;

  if(process->toFile)
  {
    fclose(process->toFile);
    process->toFile = 0;
  }

  if(process->commFd[1] > 0)
  {
    close(process->commFd[1]);
    process->commFd[1] = 0;
  }

  if(process->commPipe[1])
  {
/*    CloseHandle(process->commPipe[1]);  this handle should alreay be closed because of the former closing actions... */
    process->commPipe[1] = 0;
  }
}


unsigned int rss_process_getId(RSS_Process process)
{
  if(!process || !process->running)
    return 0;

  return (unsigned int)process->processHandle;
}


#else

/* UNIX implementation */

#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>


/* FIXME: Find a better value or an OS specific constant! */
#ifndef MAX_OPEN_FD
#define MAX_OPEN_FD 20
#endif

#ifndef STDIN_FD
#define STDIN_FD 0
#endif
#ifndef STDOUT_FD
#define STDOUT_FD 1
#endif
#ifndef STDERR_FD
#define STDERR_FD 2
#endif

struct RSS_Process_Struct
{
  const char  *name;
  const char **argv;
  int          argc;
  pid_t        processId;
  int          commPipe[2]; /* communication file descriptors... */
  FILE        *fromFile;
  FILE        *toFile;
  int          running;
};


static RSS_Process createProcessObject(const char **argv)
{
  const char  *arg;
  int          i;
  RSS_Process  process = (RSS_Process)malloc(sizeof(struct RSS_Process_Struct));

  if(!process)
    return 0;

  if(!argv || !argv[0])
  {
    free(process);
    return 0;
  }

  process->name = strdup(argv[0]);

  /* count the number of arguments */
  process->argc = 0;
  arg = argv[0];
  while(arg)
  {
    process->argc++;
    arg = argv[process->argc];
  }

  process->argv = (const char **)malloc((process->argc + 1) * sizeof(const char *));
  if(!process->argv)
  {
    free(process);
    return 0;
  }

  /* duplicate arguments (incl. null termination!) */
  for(i = 0; i < process->argc; i++)
    process->argv[i] = strdup(argv[i]);
  process->argv[process->argc] = 0;

  /* initialize the other fields... */
  process->processId = -1;
  process->fromFile  = 0;
  process->toFile    = 0;
  process->running   = 0;
  process->commPipe[0] = 0;
  process->commPipe[1] = 0;

  return process;
}


RSS_Process rss_process_create(const char *name, ...)
{
  va_list arglist;
  int i;
  int j;
  const char *arg;
  const char **argv;
  RSS_Process process;

  /* count arguments */
  i = 0;
  va_start(arglist, name);
  while((arg = va_arg(arglist, const char *)))
    i++;
  va_end(arglist);

  /* create argument vector */
  argv = (const char **)malloc((i + 2) * sizeof(const char *));
  if(!argv)
    return 0;

  i = 0;
  argv[i] = strdup(name);
  i++;
  va_start(arglist, name);
  while((arg = va_arg(arglist, const char *)))
  {
    argv[i] = strdup(arg);
    i++;
  }
  va_end(arglist);
  argv[i] = 0;

  /* initialize the process structure... */
  process = rss_process_createv(argv);

  /* release argument vector (it has been copied by rss_process_createv()) */
  for(j = 0; j <= i; j++)
    free((void *)argv[i]);
  free((void *)argv);

  return process;
}



RSS_Process rss_process_createv(const char **argv)
{
  return createProcessObject(argv);
}


void rss_process_release(RSS_Process process, RSS_Process_KillMode killMode)
{
  int i;

  if(!process)
    return;

  rss_process_stop(process, killMode);

  free((void *)process->name);
  for(i = 0; i <= process->argc; i++)
    free((void *)process->argv[i]);
  free((void *)process->argv);

  free(process);

  /* from and to channels have been closed by rss_process_stop()... */
}


int rss_process_start(RSS_Process process, int flags)
{
  int toPipe[2];
  int fromPipe[2];
  int parentChannels[2];
  int childChannels[2];
  int i;

  parentChannels[0] = 0;
  parentChannels[1] = 0;
  childChannels[0]  = 0;
  childChannels[1]  = 0;

  if(flags & RSS_PROCESS_TO)
  {
    if(pipe(toPipe) < 0)
      return 0;

    parentChannels[1] = toPipe[1];
    childChannels[0]  = toPipe[0];
  }

  if(flags & RSS_PROCESS_FROM)
  {
    if(pipe(fromPipe) < 0)
    {
      if(toPipe[0] != 0)
        close(toPipe[0]);
      if(toPipe[1] != 0)
        close(toPipe[1]);

      return 0;
    }

    parentChannels[0] = fromPipe[0];
    childChannels[1]  = fromPipe[1];
  }

  process->processId = fork();
  if(process->processId < 0)
  {
    if(toPipe[0])
      close(toPipe[0]);
    if(toPipe[1])
      close(toPipe[1]);
    if(fromPipe[0])
      close(fromPipe[0]);
    if(fromPipe[1])
      close(fromPipe[1]);

    return 0;
  }

  if(process->processId == 0)
  {
    /* child process */
    if(parentChannels[0])
      close(parentChannels[0]);
    if(parentChannels[1])
      close(parentChannels[1]);

    /* close all file descriptors that are not for child's usage... */
    for(i = 0; i < MAX_OPEN_FD; i++)
    {
      if(i != childChannels[0] && i != childChannels[1]
          && i != STDIN_FD && i != STDOUT_FD && i != STDERR_FD)
      {
        close(i);
      }
    }

    /* redirect stdin and stdout if desired... */
    if(flags & RSS_PROCESS_TO)
    {
      if(dup2(childChannels[0], STDIN_FD) < 0)
        exit(1);
      close(childChannels[0]);
    }
    if(flags & RSS_PROCESS_FROM)
    {
      if(dup2(childChannels[1], STDOUT_FD) < 0)
        exit(1);
      close(childChannels[1]);
    }

    /* ok, now execute the command... */
    execv(process->argv[0], (char **)process->argv);

    /* this point is only reached in case of an error! */
    exit(1);
    return 1; /* to avoid a compiler error */
  }
  else
  {
    /* parent process */
    if(childChannels[0])
      close(childChannels[0]);
    if(childChannels[1])
      close(childChannels[1]);

    process->commPipe[0] = parentChannels[0];
    process->commPipe[1] = parentChannels[1];
    process->running     = 1;

    return 1;
  }
}


int rss_process_isAlive(RSS_Process process)
{
  int status;

  if(!process || !process->running)
    return 0;

  process->running = waitpid(process->processId, &status, WNOHANG) == 0;
  return process->running;
}


void rss_process_stop(RSS_Process process, RSS_Process_KillMode killMode)
{
  int status;

  if(!process || !process->running)
    return;

  if(killMode == RSS_PROCESS_IMMEDIATELY)
  {
    if(waitpid(process->processId, &status, WNOHANG) == 0)
    {
      kill(process->processId, SIGINT);
      rss_sleep(2);
      if(waitpid(process->processId, &status, WNOHANG) == 0)
        kill(process->processId, SIGKILL);
    }
  }

  rss_process_closeFrom(process);
  rss_process_closeTo(process);

  if(killMode == RSS_PROCESS_WAIT)
  {
    while(waitpid(process->processId, &status, WNOHANG) < 0)
    {
      if(errno != EINTR)
        break;
    }
  }

  process->processId = -1;
  process->running   = 0;
}


int rss_process_getFromFd(RSS_Process process)
{
  if(!process)
    return 0;

  return process->commPipe[0];
}


int rss_process_getToFd(RSS_Process process)
{
  if(!process)
    return 0;

  return process->commPipe[1];
}


FILE *rss_process_getFromFile(RSS_Process process)
{
  if(!process || !process->running)
    return 0;

  if(!process->fromFile)
    process->fromFile = fdopen(rss_process_getFromFd(process), "r");

  return process->fromFile;
}


FILE *rss_process_getToFile(RSS_Process process)
{
  if(!process || !process->running)
    return 0;

  if(!process->toFile)
    process->toFile = fdopen(rss_process_getToFd(process), "w");

  return process->toFile;
}


void rss_process_closeFrom(RSS_Process process)
{
  if(!process)
    return;

  if(process->fromFile)
  {
    fclose(process->fromFile);
    process->fromFile = 0;
  }

  if(process->commPipe[0])
  {
    close(process->commPipe[0]);
    process->commPipe[0] = 0;
  }
}


void rss_process_closeTo(RSS_Process process)
{
  if(!process)
    return;

  if(process->toFile)
  {
    fclose(process->toFile);
    process->toFile = 0;
  }

  if(process->commPipe[1])
  {
    close(process->commPipe[1]);
    process->commPipe[1] = 0;
  }
}


unsigned int rss_process_getId(RSS_Process process)
{
  if(!process || !process->running)
    return 0;

  return process->processId;
}


#endif


int rss_process_send(RSS_Process process, const char *buf, int size)
{
  int result = 0;
  int fd;

  fd = rss_process_getToFd(process);
  result = write(fd, buf, size);

  return result;
}


int rss_process_receive(RSS_Process process, char *buf, int size)
{
  int result = 0;
  int fd;

  fd = rss_process_getFromFd(process);
  result = read(fd, buf, size);

  return result;
}

