// child.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

int _tmain(int argc, _TCHAR* argv[])
{
  // first read something from stdin...

  char buf[1024];
  fgets(buf, 1024, stdin);

  // now write something to stdout...
  printf("----%s---\n", buf);

	return 0;
}

