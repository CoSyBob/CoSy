// test.cpp : Defines the entry point for the console application.
//


#include <stdio.h>
#include <string>
#include "../rss_process/rss_process.h"


int main(int argc, char **argv)
{
  RSS_Process process;
  printf("test for rss_process...\n");
  printf("-----------------------\n");

  process = rss_process_create("c:\\software\\reva\\reva\\bin\\reva.exe", 0);
  if(!process)
    fprintf(stderr, "error...\n");
  else
  {
    if(!rss_process_start(process, RSS_PROCESS_ALL))
      fprintf(stderr, "cannot start the process...\n");
    else
    {
      std::string theString = ".\" Hello world!\" cr bye";
      int fromFd = rss_process_getFromFd(process);
      int toFd   = rss_process_getToFd(process);
      printf("from fd: <%d>\n", fromFd);
      printf("  to fd: <%d>\n", toFd);

      int bytesSent = rss_process_send(process, theString.c_str(), theString.size());
      printf("number of bytes sent: <%d>\n", bytesSent);

      rss_process_closeTo(process);

      char buf[1024];
      int bytesRead = rss_process_receive(process, buf, 1024);
      printf("number of bytes received: <%d>\n", bytesRead);

      buf[bytesRead - 1] = 0;
      printf("the process says: <--- %s --->\n", buf);
    }

    rss_process_release(process, RSS_PROCESS_WAIT);
  }

  printf("ok, bye...\n");
	return 0;
}

